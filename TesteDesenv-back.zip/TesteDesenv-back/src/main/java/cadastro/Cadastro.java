package cadastro;

import java.io.Serializable;
import java.util.List;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

@Entity
@Table(name = "Cadastro", schema = "public")
public class Cadastro implements Serializable {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;
    
    @Size(min = 3, message = "O campo cliente precisa ter no mínimo 3 caracteres")
    @NotNull(message = "O campo cliente não pode ser nulo")
    private String cliente;
    
    @NotNull(message = "O campo limite não pode ser nulo")
    @Min(value = 0, message = "O campo limite não pode ser negativo")
    private Double limite; 
    
    
    @NotNull(message = "O campo risco não pode ser nulo")
    @Min(value = 0, message = "O campo risco não pode ser negativo")
    private String risco; 
    
    public Cadastro() {
    }

    public Cadastro(String risco, String cliente, Double limite) {
        this.risco = risco;
        this.cliente = cliente;
        this.limite = limite;
    }

    public String getCliente() {
        return cliente;
    }

    public Double getLimite() {
        return limite;
    }

    public String getRisco() {
        return risco;
    }

    public void setCliente(String cliente) {
        this.cliente = cliente;
    }

    public void setLimite(Double limite) {
        this.limite = limite;
    }

    public void setRisco(String risco) {
        this.risco = risco;
    }
    
    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

 
}
