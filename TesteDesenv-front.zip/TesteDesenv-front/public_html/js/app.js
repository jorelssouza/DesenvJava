var app = angular.module('cadastroApp', ['ngRoute', 'ngResource']);

app.config(function ($routeProvider) {
    $routeProvider.when('/cadastro', {
        templateUrl: 'templates/cadastro.html',
        controller: 'CadastroController'
    }).when('/cadastro/:id', {
        templateUrl: 'templates/cadastro.html',
        controller: 'CadastroController'
    });
});



app.controller('CadastroController', function ($routeParams, $scope, $location, CadastroService) {

    function salvar(cadastro) {
        $scope.cadastro = {};
        return CadastroService.salvar(cadastro);
    }
});

app.service('CadastroService', function (CadastroResource) {

    this.salvar = function (cadastro) {
        return CadastroResource.salvar(cadastro).$promise;
    };

});


app.factory('CadastroResource', function ($resource) {

    var uri = 'http://localhost:8080/api/webresources/cadastro/:id';

    return $resource(uri, {}, {
        salvar: {
            method: 'POST'
        }
    });
});