﻿CREATE DATABASE cadastroCliente;

CREATE TABLE cadastro (
	id serial,
	nome VARCHAR(100),
	limite DOUBLE PRECISION,
	risco VARCHAR(11),
	PRIMARY KEY(id)
);

